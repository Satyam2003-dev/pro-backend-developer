const express = require("express");
const app = express();

// swagger docs route

const swaggerUi = require('swagger-ui-express');
const fs = require("fs")
const YAML = require('yaml')
const file  = fs.readFileSync('./swagger.yaml', 'utf8')
const swaggerDocument = YAML.parse(file)

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

const format = require("date-format");
const port = process.env.port || 4000;

app.get("/", (req, res) => {
  res.status(200).send("Hello World!");
});


app.get("/api/v1/insta", (req, res) => {
  const instaSocial = {
    username: "anoynomoushacker",
    name: "Satyam Kumar",
    followers: 50,
    following: 30,
    Date: format.asString("dd-MM-yyyy - hh:mm:ss", new Date()),
  };

  res.status(200).json(instaSocial);
});

app.get("/api/v1/facebook", (req, res) => {
  const instaSocial = {
    username: "satyamkumar",
    name: "Satyam Kumar",
    followers: 200,
    following: 100,
    Date: format.asString("dd-MM-yyyy - hh:mm:ss", new Date()),
  };

  res.status(200).json(instaSocial);
});

app.get("/api/v1/linkedin", (req, res) => {
  const instaSocial = {
    username: "satyamkumar2003",
    name: "Satyam Kumar",
    followers: 200,
    following: 100,
    Date: format.asString("dd-MM-yyyy - hh:mm:ss", new Date()),
  };

  res.status(200).json(instaSocial);
});

app.get("/api/v1/:token", (req, res) => {
  console.log(req.params.token);
  res.status(200).json({param: req.params.token});
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
